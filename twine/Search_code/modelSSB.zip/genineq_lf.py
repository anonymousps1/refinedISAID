import sys
import os
import re


def genineq():

    with open("twine_mini.txt", "r")as rd:
        line = rd.readline()
    line2 = line.split(",")
    line2.pop(-1)

    char = [[0 for i in range(2)] for j in range(16)]

    for i in range(14):
        char[i][0] = chr(65 + i) + "\'" 
        char[i][1] = chr(65 + i) 
    char[14][0] = "P\'"
    char[14][1] = "P"
    char[15][0] = "Q\'"
    char[15][1] = "Q"
    print(char)
    #exit()
    ineq = []
    for l in line2:
        subineq = []
        for ll in char:
            if l.count(ll[0]) > 0:
                subineq.append(-1)
            elif l.count(ll[1]):
                subineq.append(1)
            else:
                subineq.append(0)
        ineq.append(subineq)

    for l in ineq:
        so = l.count(-1)
        l.append(so-1)
        l.append(">=")



    #print(ineq)
    print(len(line2))
    print(ineq[0])

    return ineq


if __name__ == "__main__":
    genineq()
    pass
