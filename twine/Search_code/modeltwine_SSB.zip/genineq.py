import sys
import re
import os
#from ineq import *


def genineq():
    with open("ineq.txt", "r")as rd:
        ineq = rd.read()
    L = []
    for i in range(len(ineq)):
        L.append(ineq[i])
    #print(ineq)
    L.pop(-1)
    #print(L)

    LL = [[0 for i in range(16)] for j in range(1342)]
    #print(LL)
    for i in range(1342):
        for j in range(16):
            LL[i][j] = L[i*16+j]
    #print(LL)

    for l in LL:
        count = 0
        for ll in l:
            if ll == "1":
                count += 1
        l.append(count-1)

    #print(LL)


    LLL = [[0 for i in range(16)] for j in range(1342)]


    for i in range(1342):
        for j in range(16):
            if LL[i][j] == '-':
                LLL[i][j] = 0
            if LL[i][j] == '0':
                LLL[i][j] = 1
            if LL[i][j] == '1':
                LLL[i][j] = -1
            #else:
                #LLL[i][j] = LL[i][j] 

    #print("*************")
    #print(LLL)

    for l in LLL:
        count = 0
        for ll in l:
            if ll == -1:
                count += 1
        l.append(count-1)

    for l in LLL:
        l.append(">=")
    #print(LLL)

    return LLL



    #l.append(ineq[0, 18])
    #print(l)
    #print(len(L) /16)




if __name__ == "__main__":
    genineq()
    pass

